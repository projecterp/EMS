package Helper;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.derby.tools.sysinfo;
import org.apache.struts2.ServletActionContext;

import Action.Mailer;
import Entity.Dept;
import Entity.Employee;
import Entity.Grievance;
import Entity.Manager;
import Entity.Message;
import Entity.News;
import Entity.NotificationObject;
import Entity.Notifications;

public class DbHandler {

	private EntityManager em = null;
	HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
	HttpServletRequest req=ServletActionContext.getRequest();
	// public EntityManager em=null;
	public DbHandler() {
		em = DbConnect1.getEm();
	}

	public EntityManager getEntityManager() {
		return em;
	}

	public void saveEmployee(Employee e) {
		
		em.getTransaction().begin();
		em.persist(e);
		em.getTransaction().commit();
		
	}

	public String sendMessage() {
		try{
		HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
		String rid=req.getParameter("rid");
		String subject=req.getParameter("subject");
		String text=req.getParameter("text");
		String eid=sesssion.getAttribute("id").toString();
		Message m=new Message();
		m.setReceiverid(rid);
		m.setSubject(subject);
		m.setSenderid(eid);
		m.setText(text);
		m.setTime();
		Employee e=em.find(Employee.class,eid);
        text=e.getName()+" sent you a message.";
		Notifications r=em.find(Notifications.class,rid);
		if(r==null){
			r=new Notifications();
			r.setEid(rid);
		}
		em.getTransaction().begin();
		em.persist(m);
		r.push(m.getId(),0,text);
		em.getTransaction().commit();
        return "success";
		}
		catch(Exception e){
			System.out.println(e);
			return "error";
		}
//		NotificationObject n = new NotificationObject(m.getReceiverid(), m.getId(), 1, m.getText(), m.getTime());
//		saveNotificationObject(n);
//		updateNotifications(m.getReceiverid());
	}
		
	public String sendGrievance() {
		try{
		HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
//		String rid=req.getParameter("rid");
		String text=req.getParameter("text");
		String eid=sesssion.getAttribute("id").toString();
		Employee e=em.find(Employee.class,eid);	
		System.out.println(eid);
		//Manager man=em.find(Manager.class,getManager(e.getDept()).getId());
	    Grievance m=new Grievance();
        m.setEid(eid);
        m.setText(text);
        m.setTitle("");
        m.setDept(e.getDept());
		m.setTime();

        text=e.getName()+" filed a grievance.";
		Notifications r=em.find(Notifications.class,getManager(e.getDept()).getId());
		if(r==null){
			r=new Notifications();
			r.setEid(getManager(e.getDept()).getId());
		}
		em.getTransaction().begin();
		em.persist(m);
		r.push(m.getId(),1,text);
		em.getTransaction().commit();		
		}
		catch(Exception e){
			System.out.println(e);
			return "error";
		}
		return "success";
	}

	public String sendNews() {
		try{
//		String rid=req.getParameter("rid");
		String text=req.getParameter("text");
		String eid=sesssion.getAttribute("id").toString();
		Employee e=em.find(Employee.class,eid);	
	    News m=new News();
        m.setSender(eid);
        m.setSname("");        
        m.setText(text);
		m.setTime();   
        text=e.getName()+" published a new news";
	
		em.getTransaction().begin();
		em.persist(m);
		List<Employee> el = getAllEmployees(e.getDept());		
		for(Employee e1:el)
		{
			if(e1.getId()!=e.getId()){
				Notifications r=em.find(Notifications.class,e1.getId());
				if(r==null){
					r=new Notifications();
					r.setEid(e1.getId());
				}
				System.out.println("pushing");
				r.push(m.getId(),2,text);
				em.persist(r);
			}

		}

		em.getTransaction().commit();					
		}
		catch(Exception e){
			System.out.println(e);
			return "error";
		}
		return "success";
	}

    public String sendMail(){
    	HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
		String rid=req.getParameter("rid");
		String text=req.getParameter("text");
		String subject=req.getParameter("subject");
		System.out.println(text);
		String eid=sesssion.getAttribute("id").toString();
		try{
		 Mailer ml=new Mailer();
		 ml.processRequest(rid, subject,text);
		  //MailWAttachment.MailSender(rid, subject,text);
		  return "success";
		}
		catch(Exception e){
			System.out.println(e);
			return "error";
		}
		
/*		Message m=new Message();
		m.setReceiverid(rid);
		m.setSenderid(eid);
		m.setText(text);
		m.setTime();
		Employee e=em.find(Employee.class,eid);
        text=e.getName()+" sent you a message.";
		Notifications r=em.find(Notifications.class,rid);
		if(r==null){
			r=new Notifications();
		}
		*/
    }
	
	
	public void saveDept(Dept d) {
		em.getTransaction().begin();
		em.persist(d);
		em.getTransaction().commit();
	}

	public Employee getProfile(String id) {
        Employee e=em.find(Employee.class,id);
        if(e==null){
        	return new Employee();
        }
        return e;
	}

	public boolean deleteEmployee() {
		HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
		String id=req.getParameter("id");
        try{
			em.getTransaction().begin();
			em.remove(getProfile(id));
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}

	}

	public boolean updateEmployeeRatings() {
		HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
		String eid=req.getParameter("eid");
		int rating=Integer.valueOf(req.getParameter("rating"));
		try {
			Query q = em.createQuery("update Employee rating=" + rating + "  where id=" + eid);
			em.getTransaction().begin();
			q.executeUpdate();
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}


	public boolean chnageEmployeeDepartment(String eid,String old,String nw){
		Employee e=em.find(Employee.class,eid);
		try{
			e.setDept(nw);
			saveEmployee(e);
		}
		catch(Exception e1){
			System.out.println(e1);
			return false;
		}
		return true;
	}
	

	
	public Employee getEom(String dname) {
		Employee eom = new Employee();
		Query q = em.createQuery("select e from Employee e where e.dept='" + dname +"' order by e.rating DESC");
	//	List<Employee> el = new ArrayList<Employee>();
		try {
		  List<Employee> elist=q.getResultList();
		  if(elist==null || elist.size()==0){
			  return new Employee();
		  }
		  return elist.get(0);
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
		//	el = new ArrayList<Employee>();
			eom = new Employee();
		}
		return eom;

	}

	public boolean clearAllEmployees() {
		System.out.println("clear empoyees list");

		try {
			Query q = em.createQuery("delete from Employee e");

			em.getTransaction().begin();
			q.executeUpdate();
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}

	}

	public List<Employee> getAllEmployees(String dName) {

		System.out.println("all empoyees list");
		Query q = em.createQuery("SELECT e from Employee e where e.dept=" + '\"' + dName + '\"');
		List<Employee> e1List = new ArrayList<Employee>();

		try {
			e1List = q.getResultList();
			if(e1List==null || e1List.size()==0){
				return new ArrayList<Employee>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			e1List = new ArrayList<Employee>();
		}
		return e1List;
	}

	public List<Employee> getAllEmployees(){

		System.out.println("all empoyees list");
		Query q = em.createQuery("SELECT e from Employee e ");
		List<Employee> e1List = new ArrayList<Employee>();

		try {
			e1List = q.getResultList();
			if(e1List==null || e1List.size()==0){
				return new ArrayList<Employee>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			e1List = new ArrayList<Employee>();
		}

		return e1List;
		
	}
	
	public List<Dept> getAllDepartments() {
		Query q = em.createQuery("select d from Dept d ");
		List<Dept> dl = new ArrayList<Dept>();

		try {
			dl = q.getResultList();
			System.out.println(dl.size());
			if(dl==null){
				System.out.println("sdjsdhjks");
				return new ArrayList<Dept>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			dl = new ArrayList<Dept>();
		}
		return dl;

	}

	public Employee getManager(String dName) {
		Employee dm = new Employee();

		// get the department from db
		Dept dt = em.find(Dept.class,dName);
		if(dt==null){
			return new Employee();
		}
		else{
			dm=em.find(Employee.class,dt.getManager());
			if(dm==null){
				return new Employee();
			}
			return dm;
		}
	}
	public List<NotificationObject> getAllNotifications(String eid) {
		Query q = em.createQuery("select n from NotificationObject n where n.sid='" + eid+"'");
		List<NotificationObject> nl = new ArrayList<NotificationObject>();
		try {
			nl = q.getResultList();
			if(nl==null){
				return new ArrayList<NotificationObject>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			nl = new ArrayList<NotificationObject>();
		}
		return nl;

	}

	public List<News> getNews(String eid) {
		Query q = em.createQuery("select n from News n");
		List<News> nl = new ArrayList<News>();
		try {
			nl = q.getResultList();
			if(nl==null){
				return new ArrayList<News>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			nl = new ArrayList<News>();
		}
		return nl;

	}
	
	
	public List<Grievance> getAllGrievancesofEmployee(String eid) {
		Query q = em.createQuery("select g from Grievance g where g.eid=" + eid);
		List<Grievance> gl = new ArrayList<Grievance>();
		try {
			gl = q.getResultList();
			if(gl==null){
				return new ArrayList<Grievance>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			gl = new ArrayList<Grievance>();
		}
		return gl;
	}

	
	
	public List<Message> getAllMessages(String id){
		//receiverid;;
		Query q = em.createQuery("select m from Message m where m.receiverid=" + id);
		List<Message> gl = new ArrayList<Message>();
		try {
			gl = q.getResultList();
			if(gl==null){
				return new ArrayList<Message>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			gl = new ArrayList<Message>();
		}
		return gl;
	}
	
	
	public List<Grievance> getAllGrievances(String dept) {
		System.out.println("query get allgriecvannce called\n");
//		ArrayList<Grievance> gal = new ArrayList<Grievance>();
		Query q = em.createQuery("select g from Grievance g where g.dept=" + "\"" + dept + "\"");
		// Query q= em.createQuery("select g from Grievance g ");
		List<Grievance> gl = new ArrayList<Grievance>();
		try {
			gl = q.getResultList();
			if(gl==null){
				return new ArrayList<Grievance>();
			}
		} catch (Exception e) {
			System.out.println(" select query not executed properly      " + e);
			gl = new ArrayList<Grievance>();
		}
		return gl;
	}

	
	
	public String updateGrievance() {
		HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
		String gid=req.getParameter("gid");
		System.out.println(gid);
		try {
			Query q = em.createQuery("update Grievance set status=" + true + " where id='" + gid+"'");
			em.getTransaction().begin();
			q.executeUpdate();
			em.getTransaction().commit();
			return "success";
		} catch (Exception e) {
			System.out.println(e);
			return "error";

		}
	}

	public String updateManager() {
		HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
		HttpServletRequest req=ServletActionContext.getRequest();
       String dname=req.getParameter("dept");
       String mid=req.getParameter("eid");
		try {
			 Dept d=em.find(Dept.class,dname);
		     Employee old=em.find(Employee.class,d.getManager());
		     Employee n=em.find(Employee.class,mid);
		     d.setManager(mid);
		     old.setPosition("reg");
		     n.setPosition("manager");
		     em.getTransaction().begin();
		     em.persist(d);
		     em.persist(old);
		     em.persist(n);
		     em.getTransaction().commit();
		     return "success";
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	public boolean assignManager(String dname, String mid) {
		try {			 
			System.out.println("assign Manager: "+dname+mid);
			 Dept d=em.find(Dept.class,dname);
		    // Employee old=em.find(Employee.class,d.getManager());
		     Employee n=em.find(Employee.class,mid);
		     d.setManager(mid);
		     //old.setPosition("reg");
		     n.setPosition("manager");
		     em.getTransaction().begin();
		     em.persist(d);
		     //em.persist(old);
		     em.persist(n);
		     em.getTransaction().commit();
		     System.out.println("yes");
		     return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}

	}

	public String addDept() {
		try{
			HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
			HttpServletRequest req=ServletActionContext.getRequest();
		String dept=req.getParameter("dept");
		Dept d=new Dept();
		d.setName(dept);
		d.setManager("");
		em.getTransaction().begin();
		em.persist(d);
		em.getTransaction().commit();
		System.out.println(em.find(Dept.class,d.getName()));
		}
		catch(Exception e){
			System.out.println(e);
			return "error";
		}
	    return "success";

	}

	public String deleteDepartment() {
		String dname=req.getParameter("dept");
		try {
			HttpSession sesssion=ServletActionContext.getRequest().getSession(false);
			HttpServletRequest req=ServletActionContext.getRequest();
			em.getTransaction().begin();
			Dept d=em.find(Dept.class,dname);
			List<Employee> eList=getAllEmployees(dname);
			for(Employee e:eList){
				Notifications nf=em.find(Notifications.class,e.getId());
				List<NotificationObject> noList=getAllNotifications(e.getId());
				for(NotificationObject no:noList){
					em.remove(no);
				}
				em.remove(nf);
				em.remove(e);
			}
			em.remove(d);
			em.getTransaction().commit();
			return "success";
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	
	
	public Dept getDept(String dName) {
		Dept d=em.find(Dept.class,dName);
		if(d==null){
			return new Dept();
		}
		return d;
	}
}
