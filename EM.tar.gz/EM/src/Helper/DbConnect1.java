package Helper;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbConnect1 {
	// Injected database connection:
	private static EntityManager em = null;

	public static void connect() {

	    EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Eclipselink_JPA" );
	    em = emfactory.createEntityManager();
	    
		System.out.println(getEm());
		System.out.println("Database Loaded");
	}

	public static void close() {
		em.close();
	}

	public static EntityManager getEm() {
		if (em == null || !em.isOpen())
			connect();
		return em;
	}

	public static void setEm(EntityManager em1) {
		em = em1;
	}


}
