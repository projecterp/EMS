package Entity;

import java.sql.Date;
import java.sql.Timestamp;
import Helper.DbHandler;

public class Admin{

	private String id;
	private String password;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	/*
	public Employee getProfile(String eid){
		manage m1=new manage();
		return m1.getProfile(eid);
	}

	
	public void publishNews(String text,Timestamp t){	
		News n = new News(this.name,this.id, text, t);
		manage m1=new manage();
		m1.saveNews(n);
	}
    
	public void sendMessage(String rid,String text,Timestamp time){
		Message m=new Message(this.id, rid, text, time);
		manage m1=new manage();
		m1.saveMessage(m);
	}

	public void updateManager(String dname,String mid){
		manage m1=new manage();
		m1.updateDepartmentManager( dname,mid);
	}

	public void deleteManger(String dname){
		manage m1=new manage();
		m1.deleteDepartmentManager( dname);		
	}
	
	public void assignManger(String dname,String mid){
		manage m1=new manage();
		m1.assignDepartmentManager( dname, mid);
	}

	public void addDepartment(String dname){
		manage m1=new manage();
		Dept d =new Dept(dname);
		m1.addDept( d);
	}
	
	public void deleteDepartment(String dname){
		manage m1=new manage();
		m1.deleteDepartment(name);
	}
*/		
}
