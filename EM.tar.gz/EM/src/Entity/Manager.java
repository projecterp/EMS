package Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Manager {

	@Id
	private String eid;
	private String dept;
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
}
