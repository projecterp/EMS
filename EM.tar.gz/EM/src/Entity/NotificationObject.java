package Entity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class NotificationObject {

	@Id
	@GeneratedValue
	private String id;
	private String sid;
	private String oid;
	private int type;// 0=>message,1=>grievance,2=>news
	private String text;
	// private Date time;
	private String time;

	public NotificationObject() {

	}

	public NotificationObject(String sid, String oid, int type, String text) {
		this.sid = sid;
		this.oid = oid;
		this.type = type;
		this.text = text;
		setTime();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getoid() {
		return oid;
	}

	public String getsid() {
		return sid;
	}

	public void setsid(String sid) {
		this.sid = sid;
	}

	public void setoid(String oid) {
		this.oid = oid;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getTime() {
		return time;
	}

	public void setTime() {
		SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd HH:mm");
		Date date = new Date();
		sd.setTimeZone(TimeZone.getTimeZone("IST"));
		this.time = sd.format(date);
	}

}
