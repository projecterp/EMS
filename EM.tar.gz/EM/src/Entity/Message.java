package Entity;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Message {
	
	@Id
	@GeneratedValue
	private String id;
	
	private String senderid;
	private String receiverid;
	private String text;
	private String subject;
//	private Date time;
	private String time;
	
	public Message(){
		
	}
/*	
	public Message(String  senderid,String receiverid,String text){
		this.senderid = senderid;
		this.receiverid = receiverid;
		this.text = text;
		setTime();
		
	}
*/	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSenderid() {
		return senderid;
	}
	public void setSenderid(String senderid) {
		this.senderid = senderid;
	}
	public String getReceiverid() {
		return receiverid;
	}
	public void setReceiverid(String receiverid) {
		this.receiverid = receiverid;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getTime() {
		return time;
	}
	public void setTime() {
		SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd HH:mm");
		Date date = new Date();
		sd.setTimeZone(TimeZone.getTimeZone("IST"));
		this.time = sd.format(date);
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
  
	 
	
	
}
