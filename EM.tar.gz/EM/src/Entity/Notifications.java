package Entity;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.Query;

import Entity.NotificationObject;
import Helper.DbConnect1;

@Entity
public class Notifications {
	
	@Id
	private String eid;
	private int total;

	public Notifications(){
		total=0;
	}
	
	public void push(String oid,int type, String text) {
		if (!DbConnect1.getEm().getTransaction().isActive()) {
			DbConnect1.getEm().getTransaction().begin();
			DbConnect1.getEm().persist(new NotificationObject(eid, oid, type, text));
			DbConnect1.getEm().getTransaction().commit();
		} else {
			DbConnect1.getEm().persist(new NotificationObject(eid, oid, type, text));
		}
		total++;
	}
	
	public long getMessageCount(){
		System.out.println("msgcount");
	    long l=0;
		EntityManager em=DbConnect1.getEm();
		Query q=em.createQuery("SELECT count(c) from NotificationObject c where c.sid="+eid+" and c.type=0");
		Object a=q.getSingleResult();
		System.out.println(a);
		System.out.println(a.getClass());
		try{
		if(a!=null){
			return (Long)a; 
		}
		    return l;
		}
		catch(Exception e){
	  		return l;
		}
	}

	public long getGrievanceCount(){
		EntityManager em=DbConnect1.getEm();
		Query q=em.createQuery("SELECT count(c) from NotificationObject c where c.sid="+eid+" and c.type=1");
		Object a=q.getSingleResult();
		try{
		if(a!=null){
			return (Long)a; 
		}
		    return new Long(0);
		}
		catch(Exception e){
	  		return new Long(0);
		}

	}	
	
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	
	
}
