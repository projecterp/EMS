package Entity;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.Id;

import Helper.DbHandler;

@Entity
public class Employee{

	@Id
	private String id;
	protected String name;
	protected String contact;
	protected String dob;
//	protected int age;
	private String password;
	private int salary;
	private String email;
	private String joining_date;
	private int rating;
	private String position;
	//primary key of dep
	private String dept;
	private String image;


	public Employee(){
		
	}
		
/*
	public Employee(String name, int id, String dob, int salary, String contact, String pos,String dept) {
		//super(name, dob, contact);
		this.salary = salary;
		this.id = id;
		this.dob=dob;
		setJoining_date();
		this.rating = 0;
		this.position = pos;
		this.dept = dept;
	}
*/
	public void printDetails() {
		System.out.println("***************************************************");
		System.out.println("    id : " + id);
		System.out.println("  name : " + name);
		System.out.println("  dept : " + dept);
		System.out.println("salary : " + salary);
		System.out.println("dob : " + dob);
		System.out.println("position : "+ position);
		System.out.println("***************************************************");
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getJoining_date() {
		return joining_date;
	}

	public void setJoining_date() {
		SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd HH:mm");
		Date date = new Date();
		sd.setTimeZone(TimeZone.getTimeZone("IST"));
		this.joining_date = sd.format(date);
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

/*	
	public void sendGrievance(String text,Timestamp time,String title){
		Grievance g=new Grievance(this.dept,this.id, title, text, time, false);
		manage m1= new manage();
		m1.saveGrievance(g);
	}
	
	public ArrayList<Grievance> getAllGrievancesOfEmployee(){
		manage m1=new manage();
		return m1.getAllGrievances(this.id);
	}
	
	public ArrayList<Grievance> getAllGrievances(){
		manage m1=new manage();
		return m1.getAllGrievances(this.dept);
	}
	
	public void publishNews(String text,Timestamp time){
		News n=new News(this.name,this.id, text, time);
		manage m1= new manage();		
		m1.saveNews(n);
	}
	
	public void sendMessage(int receiverid,String text,Timestamp time){
		
		Message m= new Message(this.id, receiverid, text, time);
		manage m1= new manage();
		m1.saveMessage(m);
	}

	public void rateEmployee(int eid,int rating){
		if(this.position=="manager")
		{
			manage m1= new manage();
			m1.updateEmployeeRatings(eid,rating);
		}
		else
		{
			System.out.println("*************can't update rating\n***********");
			
		}
	}
	
	public Employee getEOM(){
		Employee e;
		manage m1 = new manage();
		e=m1.getEOM(this.dept);
		return e;
	}

	public void addEmployee(String name,int eid,Date dob,int salary,String contact,String position,String dept){
		Employee e = new Employee(name, eid, dob, salary, contact, position , dept);
		manage m1 = new manage();
		m1.saveEmployee(e);
	}

	public void deleteEmployee(int eid){
		manage m1= new manage();
		m1.deleteEmployee(eid);
	}
	
	public void updateEmployee(String name,int eid,Date dob,int salary,String contact,String position,String dept){
		manage m1= new manage();
		m1.updateEmployee(name,eid,dob,salary,contact,position,dept);
	}
	
	public Employee getProfile()
	{
		manage m1= new manage();
		return m1.getProfile(this.id);
	}

	public Employee getManager(){	
		manage m1= new manage();
		return m1.getManager(this.dept);
		
	}
	
	public Employee getEmployee(int eid)
	{
		manage m1=new manage();
		return m1.getProfile(eid);
	}
	
	public ArrayList<Employee> getAllEmployees(){
		manage m1= new manage();
		return m1.getAllEmployees(this.dept);
	}

	public void resolveGreivance(int gid){
		manage m1= new manage();
		m1.updateGrievance(gid);
	}
*/
	
	public Employee getManager(){	
		DbHandler m1= new DbHandler();
		return m1.getManager(this.dept);		
	}
	
	public List<Grievance> getAllGrievancesOfEmployee(){
		DbHandler m1=new DbHandler();
		return m1.getAllGrievancesofEmployee(this.id);
	}
	
	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	
}
