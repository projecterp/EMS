package Entity;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class News {

	@Id
	@GeneratedValue
	private String id;

	private String sname;
	private String sender;
	private String text;
//	private Date time;
	private String time;
	
	public News(){
		
	}
	public String getId()
	{
		return id;
	}
/*	
	public News(String name,String senderid,String text,Timestamp t){
		this.sname= name;
		this.sender=senderid;
		this.text = text;
		this.time = t;
	}
*/
	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}
	
	
	public String getSender() {
		return sender;
	}
	
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getTime() {
		return time;
	}
	public void setTime() {
		SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd HH:mm");
		Date date = new Date();
		sd.setTimeZone(TimeZone.getTimeZone("IST"));
		this.time = sd.format(date);
	}
	
	
	
}
