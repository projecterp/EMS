package Entity;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Firm {

	@Id
	private String name="asd";

	public Firm()
	{
		
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


//	private ArrayList<Dept> dList = new ArrayList<Dept>();

//	public ArrayList<Dept> getdList() {
//		return dList;
//	}
//
//	public void setdList(ArrayList<Dept> dList) {
//		this.dList = dList;
//	}
//
//	public void addDept(Dept e) {
//		dList.add(e);
//	}
//
//	public void removeDept(Dept e) {
//		dList.remove(e);
//	}
//
//	public Dept getDept(String name) {
//		for (Dept e : dList) {
//			if (e.getName().equals(name)) {
//				return e;
//			}
//		}
//		return null;
//	}

	public void printDetails() {
		System.out.println("firm name= " + name);

	}

}
