package Entity;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Grievance {

	@Id
	@GeneratedValue
	private String id;
	private String eid;
	private String title;
	private String text;
	private String dept;
//	private Date time;
	private String time;
	private boolean status;
	
	
	public Grievance(){
		
	}
	/*
	public Grievance(String dept,String eid,String title,String text, Timestamp time,boolean status){
		this.eid= eid;
		this.title =title;
		this.text = text;
		this.time= time;
		this.status = status;	
		this.dept = dept;
	}
	*/
//	public void prStringdetails(){
//		System.out.prStringln("eid= " + eid + "title=" + title + " text=");
//	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getTime() {
		return time;
	}

	public void setTime() {
		SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd HH:mm");
		Date date = new Date();
		sd.setTimeZone(TimeZone.getTimeZone("IST"));
		this.time = sd.format(date);
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	
	  
	
	
}
