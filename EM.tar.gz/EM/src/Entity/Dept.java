package Entity;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Dept {

	@Id
	private String name;

//	private String firm;//primary key of firm class
	private String mid;// id of manager
	
	public Dept(){
	}
//	
//	public String getF() {
//		return firm;
//	}
////
//	public void setF(String f) {
//		this.firm = f;
//	}

//for referencing other class objects we  need to declare relationships 	
//	private ArrayList<Integer> eList = new ArrayList<Integer>();

	
	public Dept(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getManager() {
		return mid;
	}

	public void setManager(String manager) {
		this.mid = manager;
	}

//	public String getFirm() {
//		return firm;
//	}
//
//	public void setFirm(String firm) {
//		this.firm = firm;
//	}

//	public ArrayList<Integer> geteList() {
//		return eList;
//	}
//	
////
//	public void seteList(ArrayList<Integer> eList) {
//		this.eList = eList;
//	}
//
//	public void addEmployee(Employee e) {
//		e.setDept(this.name);
//
//		eList.add(e.getId());
//	}
//
//	public void removeEmployee(Employee e) {
//		eList.remove(e.getId());
//	}
//
//	public Integer getEmployee(int id) {
//		for (Integer e : eList) {
//			if (e.getId().intValue() == id) {
//				return e;
//			}
//		}
//		return null;
//	}
//
	
	public void printDetails() {
		System.out.println("____________________________________________________");
		System.out.println("   name : " + name);
		System.out.println("manager : " + mid);
//		System.out.println("manager : " + ecount);
		System.out.println("____________________________________________________");
//		for (Employee e : eList) {
//			e.printDetails();
//		}
	}

}
