package Action;

import java.io.File;
import java.sql.Date;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.derby.tools.sysinfo;
import org.apache.struts2.ServletActionContext;

import Entity.*;
import Helper.*;
public class Register {

	private DbHandler db = new DbHandler();

	public DbHandler getDb() {
		return this.db;
	}

	public void setDb(DbHandler db) {
		this.db = db;
	}

	public HttpServletRequest getServletRequest() {
		return this.servletRequest;
	}

	public void setServletRequest(HttpServletRequest servletRequest) {
		this.servletRequest = servletRequest;
	}

	public int getSalary() {
		return this.salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getJoining_date() {
		return this.joining_date;
	}

	public void setJoining_date(String joining_date) {
		this.joining_date = joining_date;
	}

	public int getRating() {
		return this.rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDept() {
		return this.dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public HttpServletRequest servletRequest;
	private String id;
	protected String name;
	protected String email;
	protected String contact;
	protected String dob;

	private String password,cnf_password;
	private int salary;
	private String joining_date;
	private int rating;
	private String position;

	private String dept;
	private String image;	
	private File userImage;
	private String userImageContentType;
	private String userImageFileName;



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	// SPC SignIn process
	public String manager_signIn() {
		HttpSession session = ServletActionContext.getRequest().getSession(
				false);
		servletRequest = ServletActionContext.getRequest();
//		id = servletRequest.getParameter("id").toLowerCase();
//		dept = servletRequest.getParameter("dept");
		try {
			System.out.println(id+dept);
			db.assignManager(dept,id);
			return "success";
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	
	// Not in USE 
	// Refer CompanyMain.java for sign in and log in of company
	public String admin_signIn() {
		HttpSession session = ServletActionContext.getRequest().getSession(
				false);
		servletRequest = ServletActionContext.getRequest();
		id = servletRequest.getParameter("id");
		password = servletRequest.getParameter("password");
		try{
			Admin a=new Admin();
			a.setId(id);
			a.setPassword(password);
			return "success";
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
	}

	
	public boolean validate(String type) {
		HttpSession session = ServletActionContext.getRequest().getSession(
				false);
		servletRequest = ServletActionContext.getRequest();
		Employee r = DbConnect1.getEm().find(Employee.class,id);
		if(!password.equals(cnf_password)){
			return false;
		}
		if(r==null){
			r=new Employee();
			r.setId(id);
		}
		// Restricts multiple SignIn with same SID
		else{
			System.out.println("e1");
			return false;
		}
		try {
			String filePath = servletRequest.getSession().getServletContext()
					.getRealPath("/");
			System.out.println("Server path:" + filePath + id + "\n"+ userImageContentType);
			File fileToCreate = new File(filePath, id
					+ "."
					+ userImageContentType.substring(userImageContentType
							.indexOf('/') + 1));
			FileUtils.copyFile(this.userImage, fileToCreate);
			// System.out.println(fileToCreate.getAbsolutePath());
			System.out.println(fileToCreate.getCanonicalPath());
			r.setImage(fileToCreate.getCanonicalPath());
			// fileToCreate = new File(filePath, "gradeSheet" + id);
			// FileUtils.copyFile(this.gradesheet, fileToCreate);
			// r.setGrade_sheet(fileToCreate.getCanonicalPath());
			session.setAttribute("id", id);
			System.out.println("after setting session");
			r.setContact(contact);
            r.setDept(dept);
            r.setDob(dob);
            r.setEmail(email);
            r.setJoining_date();
            r.setName(name);
            r.setPosition(position);
            r.setRating(0);
            r.setSalary(salary);
			r.setPassword(password);
			db.saveEmployee(r);
			System.out.println("saved");
	//		Mailer m = new Mailer();
	//		m.processRequest(id + "@mnit.ac.in", "PTP Registration",
	//				"You are successfully registered at the PTP");
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}

	public String execute() {
		if (this.validate("")) {
			return "success";
		}
		return "error";
	}

	public String updateEmployee() {
       EntityManager em=DbConnect1.getEm();
   	HttpSession session = ServletActionContext.getRequest().getSession(
			false);
	servletRequest = ServletActionContext.getRequest();
		System.out.println("update employee query called\n");
		id=servletRequest.getParameter("id");
		salary=Integer.parseInt(servletRequest.getParameter("salary"));
		position=servletRequest.getParameter("position");
		dept=servletRequest.getParameter("dept");
		Employee e=em.find(Employee.class,id);
		try {
			if(salary!=0 ){
				e.setSalary(salary);
			}
			if(dept!=null && !dept.equals("")){
				if(!e.getDept().equals(dept)){
					e.setDept(dept);
				}

			}
			if(position!=null && !position.equals("") && !position.equals("manager")){
				e.setPosition(position);
			}
			db.saveEmployee(e);
			return "success";
		} catch (Exception e1) {
			System.out.println(e1);
			return "error";
		}

	}	
	
	public String updateEmployeeProfile() {
		servletRequest = ServletActionContext.getRequest();
		String id = servletRequest.getSession().getAttribute("id").toString();
		String o = servletRequest.getParameter("old_password");
		String p = servletRequest.getParameter("new_password");
		String r = servletRequest.getParameter("r_password");
		if (o.equals(p) || p.equals("") || p.equals("") || r.equals("")
				|| !p.equals(r)) {

			return "error";
		} else {
			try {
				Employee emp=DbConnect1.getEm().find(Employee.class,id);
				emp.setPassword(p);
				db.saveEmployee(emp);
				return "success";
			} catch (Exception e) {
				System.out.println(e);
				return "error";
			}
		}
	}


	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public File getUserImage() {
		return userImage;
	}

	public void setUserImage(File userImage) {
		// System.out.println("deepesh" + userImage);
		this.userImage = userImage;
	}

	public String getUserImageContentType() {
		return userImageContentType;
	}

	public void setUserImageContentType(String userImageContentType) {
		this.userImageContentType = userImageContentType;
	}

	public String getUserImageFileName() {
		return userImageFileName;
	}

	public void setUserImageFileName(String userImageFileName) {
		this.userImageFileName = userImageFileName;
	}

	public String getCnf_password() {
		return cnf_password;
	}

	public void setCnf_password(String cnf_password) {
		this.cnf_password = cnf_password;
	}



}
