package Action;

import javax.persistence.EntityManager;

import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import Entity.*;
import Helper.*;


public class Login {
	private String id, password;
	public HttpServletRequest servletRequest;
    DbHandler db=new DbHandler();
    EntityManager em=db.getEntityManager();
	public String login() {
		HttpSession session = ServletActionContext.getRequest().getSession();
		servletRequest = ServletActionContext.getRequest();
		try {
		//	this.id=this.id.toLowerCase();
			EntityManager em = DbConnect1.getEm();
			System.out.println("id:"+this.id);
			Employee e=em.find(Employee.class,id);
			if (password.equals(e.getPassword())) {
				session.setAttribute("id",id);
				//new Mailer().processRequest("pranavpatel956@gmail.com","you logged in","you logged in");
			} else {
				System.out.println("nasdsadksdgj");
				return "error";
			}  
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
		return "success";
	}

	public String manager_login() {
		HttpSession session = ServletActionContext.getRequest().getSession();
		servletRequest = ServletActionContext.getRequest();
		try {
		//	this.id=this.id.toLowerCase();
			EntityManager em = DbConnect1.getEm();
			System.out.println("id:"+this.id);
			Employee e=em.find(Employee.class,id);
			System.out.println(id);
			System.out.println(e.getPosition());
			System.out.println(e.getPassword());
			if (password.equals(e.getPassword())  && e.getPosition().equals("manager")) {
				session.setAttribute("id",id);
				System.out.println(session.getAttribute("id"));
				//new Mailer().processRequest("pranavpatel956@gmail.com","you logged in","you logged in");
			} else {
				System.out.println("nasdsadksdgj");
				return "error";
			}  
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
		return "success";
	}
	
	// Not in USE
	// Refer CompanyMain.java for company login and register
	public String admin_login() {
		HttpSession session = ServletActionContext.getRequest().getSession();
		servletRequest = ServletActionContext.getRequest();
		try {
//			this.id=this.id.toLowerCase();
//			EntityManager em = DbConnect1.getEm();
//			Admin a=em.find(Admin.class,id);
//			System.out.println("id:"+this.id);
//			Employee e=em.find(Employee.class,id);
			/*
			if (SHAclass.generateHash(password).equals(a.getPassword())) {
				session.setAttribute("id",id);
				//new Mailer().processRequest("pranavpatel956@gmail.com","you logged in","you logged in");
			} else {
				System.out.println("nasdsadksdgj");
				return "error";
			} 
			*/ 
		} catch (Exception e) {
			System.out.println(e);
			return "error";
		}
		return "success";
	}
	
	public String execute() {
		return "success";
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}

